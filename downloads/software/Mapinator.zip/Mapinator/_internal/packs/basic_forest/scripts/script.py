#Define imports and global variables here

def loop(screen):
    #Stuff happens on loop while displaying the map

def generate():
    #Stuff happens at the begining of generation